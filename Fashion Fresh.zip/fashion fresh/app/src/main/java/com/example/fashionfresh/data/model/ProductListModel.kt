package com.example.fashionfresh.data.model

data class ProductListModel(
	val products: List<ProductsItem>? = null
)
