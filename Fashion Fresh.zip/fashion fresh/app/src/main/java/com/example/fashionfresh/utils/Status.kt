package com.example.fashionfresh.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}